# Nexus cluster chart

This chart deploys the Kubernetes cluster profile: Nexus internal blob
replication, PostgreSQL/Patroni and etcd. Build and installation commands are in
[INSTALL.md](../../../docs/INSTALL.md); coordinated updates are in
[UPGRADING.md](../../../docs/UPGRADING.md).

## Source build

From the repository root:

```sh
git submodule update --init --recursive
make verify
make build-cluster-from-source
docker build --platform linux/amd64 -t steemax/nexsteem:postgres-17-patroni4.1.5-r3-amd64 deploy/cluster/postgres
```

Publish the resulting images to a registry you control and set their references
in your values. Build provenance identifies the assembled application separately
from the container digest. The production PostgreSQL image is AMD64; local ARM
fixtures are test profiles.

## Configuration reference

| Values | Purpose |
|---|---|
| `nexus.nodes`, `postgres.nodes`, `etcd.nodes`, `router.nodes` | Member data center and physical `nodeSelector` placement |
| `placement.requiredAntiAffinity`, `placement.topologyKey` | Independent hosts for members of each component |
| `*.image`, `*.pullPolicy`, `imagePullSecrets` | Accepted application/infrastructure images and registry access |
| `*.storageClass`, `*.storageSize` | Independent persistent volumes; no cross-site PVC relocation is performed |
| `postgres.allowDegradedLocalWrites` | Permit authorized writes with reduced remote durability after a site loss |
| `secrets.existingSecret`, `tls.existingSecret` | Use externally managed common secrets/certificates |
| `tls.validityDays` | Initial generated certificate lifetime; existing Secrets are reused |
| `service`, `ingress`, `networkPolicy.clientNamespaceSelector` | Client reachability, TLS termination and allowed ingress namespaces |
| `service.dockerPorts` | Frontend/Core connector pairs, normally the same port number |
| `nexus.javaOpts`, `nexus.http`, `*.resources` | JVM, HTTP concurrency/timeouts and Kubernetes resource budgets |

Defaults are three Nexus, three PostgreSQL, two routers and three etcd members.
The minimum Nexus layout is two members across two data centers. Etcd requires
three independent coordination domains, including a witness. Default selectors
use `nexus.cluster/dc`; assign real labels and storage placement accordingly.
Three PostgreSQL members with required host anti-affinity need three data hosts.

Each member keeps its own PVC. Kubernetes, DNS, ingress, control-plane quorum
and the storage provider must survive the required failures. The chart does not
provision Kubernetes or combine two independent clusters. PodDisruptionBudgets
limit voluntary evictions; they do not prevent node failure or replace the
ordered upgrade coordinator.

## Runtime behavior

Only the current fenced owner launches Core. Passive frontends are member-Ready
and route requests to that writer. A Ready Pod therefore does not prove that a
Core writer exists: check `/_cluster/health/writer` or the status checker after
installation. `OnDelete` prevents uncoordinated simultaneous replacements.

Normal successful writes require remote durable blobs and actual remote SQL
synchronous replication. Degraded local writes can continue only when enabled
and authority is current; a second failure before catch-up may lose new writes.
No successful writes are allowed without DCS/primary authority. For details,
see [replication](../../../docs/kubernetes-replication.md) and the
[module contract](../../../docs/kubernetes-cluster-contract.md).

Writable disk-backed `/tmp` supports Nexus cache creation with UID/GID 200.
Private keystores have a separate memory-backed volume. Do not size temporary
storage or Pod memory below the intended cache/upload workload.

## Secrets, TLS and networking

Generated passwords, the replica authentication key and the Nexus encryption
key are retained and reused across Helm updates. `helm.sh/resource-policy: keep`
does not protect against deletion of the namespace. Back up the key and secrets
with the database and blob state. Existing Secret keys are listed in the
`secrets.yaml` and `tls.yaml` templates.

Nexus peer, PostgreSQL and etcd traffic use separate CAs. The etcd HTTP gateway
uses a client certificate with empty CN and critical SAN, plus scoped
username/token authentication. `nx-proof` reads the configured DCS prefix and
lease TTL; it cannot mutate coordination. Core does not receive DCS/control
credentials in its environment.

NetworkPolicy is enabled by default. Allow the ingress controller's namespace
and validate your CNI enforcement. The local Kind fixture explicitly disables
these policies because kindnet does not enforce them. The default Service is
ClusterIP; expose HTTPS through the configured ingress or your LoadBalancer.
Docker connector publication does not create repositories or choose their ports
in Nexus automatically.

## Upgrade and acceptance boundaries

Helm's post-upgrade hook applies compatible extension SQL and journal indexes
through an authenticated current primary; it retains users, credentials, release
state and content. A failed hook prevents the coordinated workflow from
continuing. Core changes use the release barrier; infrastructure changes update
healthy replicas before the primary. See [UPGRADING.md](../../../docs/UPGRADING.md)
for procedures and partial-update recovery limits.

Use [verification](../../../docs/verification.md) and the isolated integration
scripts to accept your built images. Local tests do not validate physical
power fencing, a real cross-site network or a production CSI/CNI provider.
